ASPERION DIGITAL TECHNOLOGIES (OPC) PRIVATE LIMITED
Salary Breakup and CTC Structure Pack

Contents:
1. Salary Breakup Guide and Structures - master guide for HR, payroll, finance and leadership.
2. Full-Time Salary Breakup Annexure - offer-letter annexure for regular employees.
3. Senior Leadership Compensation Annexure - for CXO, head, director, principal and senior roles.
4. Internship / Trainee Stipend Annexure - stipend and learning support format.
5. Consultant / Contractor Retainer Fee Annexure - professional fee, invoice, GST/TDS, milestone and retainer structure.
6. Payroll Onboarding Declarations - employee master data, bank details, tax, PF/ESI and document checklist.
7. Salary CTC Calculator.xlsx - editable salary breakup calculator with statutory settings, component library, payroll master and offer-annexure sheet.

Important:
- All monetary figures are placeholders unless changed and approved.
- Statutory rates, wage definitions, professional tax, TDS, PF, ESI and gratuity treatment should be verified by HR, finance and legal advisors before issuing.
- The calculator is a drafting and planning tool, not a substitute for payroll software or legal review.
