ASPERION DIGITAL TECHNOLOGIES (OPC) PRIVATE LIMITED
NDA Template Pack

Files:
1. Asperion_Digital_NDA_Template.docx - editable NDA template on company letterhead.
2. Asperion_Digital_NDA_Template.pdf - print/signature-ready PDF preview.
3. Asperion_Digital_Logo.png - company logo used in the letterhead.

Before use:
- Replace all bracketed placeholders.
- Complete Schedule A for project-specific access.
- Execute on appropriate stamp paper or e-stamp paper where required.
- Obtain legal review for high-value, regulated, cross-border, employee, investor, or dispute-sensitive use cases.
